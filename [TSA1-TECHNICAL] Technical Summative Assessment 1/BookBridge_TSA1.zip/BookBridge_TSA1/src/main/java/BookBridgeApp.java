/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author angieluz cervania
 */
import java.util.Scanner;

public class BookBridgeApp {

    // Named Constants for Membership Types
    public static final String TYPE_STUDENT = "STUDENT";
    public static final String TYPE_FACULTY = "FACULTY";
    public static final String TYPE_GUEST = "GUEST";

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        final int TOTAL_TRANSACTIONS = 5;

// Coordinated parallel arrays to store 5 transactions
        String[] memberIds = new String[TOTAL_TRANSACTIONS];
        String[] memberNames = new String[TOTAL_TRANSACTIONS];
        String[] membershipTypes = new String[TOTAL_TRANSACTIONS];
        String[] isbns = new String[TOTAL_TRANSACTIONS];
        String[] bookTitles = new String[TOTAL_TRANSACTIONS];
        int[] requestedDays = new int[TOTAL_TRANSACTIONS];
        boolean[] isAvailable = new boolean[TOTAL_TRANSACTIONS];
        int[] lateDays = new int[TOTAL_TRANSACTIONS];
        
        // Calculated result arrays
        String[] statuses = new String[TOTAL_TRANSACTIONS];
        double[] lateCharges = new double[TOTAL_TRANSACTIONS];

        System.out.println("==================================================");
        System.out.println("     WELCOME TO BOOKBRIDGE LIBRARY SYSTEM        ");
        System.out.println("==================================================\n");

        // Input loop for exactly 5 valid transactions
        for (int i = 0; i < TOTAL_TRANSACTIONS; i++) {
            System.out.println("--- Entering Transaction " + (i + 1) + " of " + TOTAL_TRANSACTIONS + " ---");

            // 1. mmber ID validate
            String mId;
            do {
                System.out.print("Enter Member ID: ");
                mId = scanner.nextLine().trim();
                if (mId.isEmpty()) {
                    System.out.println("Error: Member ID cannot be blank. Re-prompting...");
                }
            } while (mId.isEmpty());
            memberIds[i] = mId;

            // 2. member Name validation
            String mName;
            do {
                System.out.print("Enter Member Name: ");
                mName = scanner.nextLine().trim();
                if (mName.isEmpty()) {
                    System.out.println("Error: Member Name cannot be blank. Re-prompting...");
                }
            } while (mName.isEmpty());
            memberNames[i] = mName;

            // 3. Membership Type Validation
            String mType;
            do {
                System.out.print("Enter Membership Type (STUDENT / FACULTY / GUEST): ");
                mType = scanner.nextLine().trim().toUpperCase();
                if (!validateMembershipType(mType)) {
                    System.out.println("Error: Invalid membership type. Must be STUDENT, FACULTY, or GUEST.");
                }
            } while (!validateMembershipType(mType));
            membershipTypes[i] = mType;

            // 4. ISBN Validation
            String isbn;
            do {
                System.out.print("Enter Book ISBN: ");
                isbn = scanner.nextLine().trim();
                if (isbn.isEmpty()) {
                    System.out.println("Error: ISBN cannot be blank. Re-prompting...");
                }
            } while (isbn.isEmpty());
            isbns[i] = isbn;

            // 5. Book Title Validation
            String title;
            do {
                System.out.print("Enter Book Title: ");
                title = scanner.nextLine().trim();
                if (title.isEmpty()) {
                    System.out.println("Error: Book Title cannot be blank. Re-prompting...");
                }
            } while (title.isEmpty());
            bookTitles[i] = title;

            // 6. Requested Loan Days Validation (1 to 30)
            int reqDays = 0;
            do {
                System.out.print("Enter Requested Loan Days (1-30): ");
                if (scanner.hasNextInt()) {
                    reqDays = scanner.nextInt();
                    scanner.nextLine(); // Clear buffer
                    if (reqDays < 1 || reqDays > 30) {
                        System.out.println("Error: Requested days must be between 1 and 30.");
                    }
                } else {
                    System.out.println("Error: Invalid number format. Re-prompting...");
                    scanner.nextLine(); // Clear invalid input
                }
            } while (reqDays < 1 || reqDays > 30);
            requestedDays[i] = reqDays;

            // 7. Availability Validation
            boolean avail = false;
            boolean validAvailInput = false;
            do {
                System.out.print("Is Book Available? (true/false or Y/N): ");
                String availInput = scanner.nextLine().trim().toLowerCase();
                if (availInput.equals("true") || availInput.equals("y") || availInput.equals("yes")) {
                    avail = true;
                    validAvailInput = true;
                } else if (availInput.equals("false") || availInput.equals("n") || availInput.equals("no")) {
                    avail = false;
                    validAvailInput = true;
                } else {
                    System.out.println("Error: Enter 'true'/'false' or 'Y'/'N'.");
                }
            } while (!validAvailInput);
            isAvailable[i] = avail;

            // 8. Late Days Validation (>= 0)
            int lDays = -1;
            do {
                System.out.print("Enter Overdue Late Days (>= 0): ");
                if (scanner.hasNextInt()) {
                    lDays = scanner.nextInt();
                    scanner.nextLine(); // Clear buffer
                    if (lDays < 0) {
                        System.out.println("Error: Late days cannot be negative.");
                    }
                } else {
                    System.out.println("Error: Invalid number format. Re-prompting...");
                    scanner.nextLine(); // Clear invalid input
                }
            } while (lDays < 0);
            lateDays[i] = lDays;

            // Calculated fields using decomposing methods
            statuses[i] = classifyRequest(membershipTypes[i], requestedDays[i], isAvailable[i]);
            double dailyFine = getDailyFine(membershipTypes[i]);
            lateCharges[i] = lateDays[i] * dailyFine;

            // Display Immediate Transaction Result
            System.out.println("\n>>> TRANSACTION " + (i + 1) + " PROCESSED <<<");
            System.out.println("Member: " + memberNames[i] + " (" + membershipTypes[i] + ")");
            System.out.println("Book: " + bookTitles[i] + " [ISBN: " + isbns[i] + "]");
            System.out.println("Requested Days: " + requestedDays[i] + " | Status: " + statuses[i]);
            System.out.printf("Late Days: %d | Estimated Late Charge: PHP %.2f\n", lateDays[i], lateCharges[i]);
            System.out.println("--------------------------------------------------\n");
        }

        // Print Final operational summary
        printSummary(memberNames, membershipTypes, bookTitles, requestedDays, statuses, lateCharges, TOTAL_TRANSACTIONS);

        scanner.close();
    }

    // --- REQUIRED METHOD DECOMPOSITION ---

    // 1. Validates permitted membership types
    public static boolean validateMembershipType(String type) {
        return type.equalsIgnoreCase(TYPE_STUDENT) ||
               type.equalsIgnoreCase(TYPE_FACULTY) ||
               type.equalsIgnoreCase(TYPE_GUEST);
    }

    // 2. Returns maximum allowed days per membership type using enhanced switch
    public static int getMaximumDays(String membershipType) {
        return switch (membershipType.toUpperCase()) {
            case TYPE_STUDENT -> 14;
            case TYPE_FACULTY -> 30;
            case TYPE_GUEST -> 7;
            default -> 0;
        };
    }

    // 3. Returns daily late fee per membership type using enhanced switch
    public static double getDailyFine(String membershipType) {
        return switch (membershipType.toUpperCase()) {
            case TYPE_STUDENT -> 5.00;
            case TYPE_FACULTY -> 2.00;
            case TYPE_GUEST -> 10.00;
            default -> 0.00;
        };
    }

    // 4. Corrected classification logic (Fixed defect: Priority given to availability & includes boundary <=)
    public static String classifyRequest(String membershipType, int requestedDays, boolean isAvailable) {
        if (!isAvailable) {
            return "RESERVED";
        }
        int maxAllowed = getMaximumDays(membershipType);
        if (requestedDays <= maxAllowed) {
            return "APPROVED";
        } else {
            return "DENIED";
        }
    }

    // 5. Prints overall operational summary
    public static void printSummary(String[] names, String[] types, String[] titles, int[] reqDays, String[] statuses, double[] lateCharges, int totalCount) {
        int approvedCount = 0;
        int reservedCount = 0;
        int deniedCount = 0;
        double totalLateCharges = 0;
        
        int maxDaysIndex = 0;

        for (int i = 0; i < totalCount; i++) {
            switch (statuses[i]) {
                case "APPROVED" -> approvedCount++;
                case "RESERVED" -> reservedCount++;
                case "DENIED" -> deniedCount++;
            }
            totalLateCharges += lateCharges[i];

            if (reqDays[i] > reqDays[maxDaysIndex]) {
                maxDaysIndex = i;
            }
        }

        System.out.println("==================================================");
        System.out.println("            FINAL OPERATIONAL SUMMARY             ");
        System.out.println("==================================================");
        System.out.printf("Total Requests Processed: %d\n", totalCount);
        System.out.printf("Approved: %d | Reserved: %d | Denied: %d\n", approvedCount, reservedCount, deniedCount);
        System.out.println("--------------------------------------------------");
        System.out.printf("Request with Greatest Requested Days:\n");
        System.out.printf("  -> %s (%s) requested %d days for \"%s\"\n", names[maxDaysIndex], types[maxDaysIndex], reqDays[maxDaysIndex], titles[maxDaysIndex]);
        System.out.println("--------------------------------------------------");
        System.out.printf("Total Estimated Late Charges: PHP %.2f\n", totalLateCharges);
        System.out.println("==================================================");
    }
}