/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author angieluz cervania
 */
public class HeatMoldingService extends SkateService {
    private int heatingDurationMinutes;
    private boolean requiresCustomPunching;

    public HeatMoldingService(String serviceId, double basePrice, int heatingDurationMinutes, boolean requiresCustomPunching) {
        super(serviceId, "Boot Heat Molding", basePrice);
        this.heatingDurationMinutes = heatingDurationMinutes;
        this.requiresCustomPunching = requiresCustomPunching;
    }

    public int getHeatingDurationMinutes() {
        return this.heatingDurationMinutes;
    }

    public boolean isRequiresCustomPunching() {
        return this.requiresCustomPunching;
    }

    @Override
    public double calculateServiceFee() {
        double customPunchingSurcharge = requiresCustomPunching ? 250.0 : 0.0;
        return getBasePrice() + customPunchingSurcharge;
    }

    @Override
    public String getFormattedSummary() {
        return super.getFormattedSummary() + String.format(" | Duration: %d mins | Custom Punching: %s",
                heatingDurationMinutes,
                requiresCustomPunching ? "Yes (+PHP 250.00)" : "No");
    }
}