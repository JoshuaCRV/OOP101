/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author angieluz cervania
 */
public class Customer {
    private String customerId;
    private String name;
    private String phoneNumber;
    private String skateBrandModel;

    public Customer(String customerId, String name, String phoneNumber, String skateBrandModel) {
        this.customerId = customerId;
        this.name = name;
        this.phoneNumber = phoneNumber;
        this.skateBrandModel = skateBrandModel;
    }

    public String getCustomerId() {
        return customerId;
    }

    public String getName() {
        return name;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public String getSkateBrandModel() {
        return skateBrandModel;
    }
}
