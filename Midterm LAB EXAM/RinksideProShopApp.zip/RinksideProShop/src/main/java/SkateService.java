/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author angieluz cervania
 */
public abstract class SkateService implements Billable {
    private String serviceId;
    private String serviceName;
    private double basePrice;
    private boolean isCompleted;

    public SkateService(String serviceId, String serviceName, double basePrice) {
        this.serviceId = serviceId;
        this.serviceName = serviceName;
        if (basePrice < 0.0) {
            this.basePrice = 0.0;
        } else {
            this.basePrice = basePrice;
        }
        this.isCompleted = false;
    }

    public void markCompleted() {
        this.isCompleted = true;
    }

    public boolean isCompleted() {
        return this.isCompleted;
    }

    public String getServiceId() {
        return this.serviceId;
    }

    public String getServiceName() {
        return this.serviceName;
    }

    public double getBasePrice() {
        return this.basePrice;
    }

    @Override
    public double calculateTotalCost() {
        return calculateServiceFee();
    }

    public abstract double calculateServiceFee();

    @Override
    public String getFormattedSummary() {
        return String.format("[%s] %s | Status: %s | Base Price: PHP %.2f | Final Fee: PHP %.2f",
                serviceId,
                serviceName,
                isCompleted ? "Completed" : "Pending",
                basePrice,
                calculateTotalCost());
    }
}