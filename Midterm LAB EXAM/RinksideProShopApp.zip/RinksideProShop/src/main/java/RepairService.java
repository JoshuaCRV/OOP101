/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author angieluz cervania
 */
public class RepairService extends SkateService {
    private String repairDescription;
    private double partsCost;

    public RepairService(String serviceId, double basePrice, String repairDescription, double partsCost) {
        super(serviceId, "Skate Repair", basePrice);
        this.repairDescription = repairDescription;
        if (partsCost < 0.0) {
            this.partsCost = 0.0;
        } else {
            this.partsCost = partsCost;
        }
    }

    public String getRepairDescription() {
        return this.repairDescription;
    }

    public double getPartsCost() {
        return this.partsCost;
    }

    @Override
    public double calculateServiceFee() {
        return getBasePrice() + partsCost;
    }

    @Override
    public String getFormattedSummary() {
        return super.getFormattedSummary() + String.format(" | Description: %s | Parts Cost: PHP %.2f",
                repairDescription,
                partsCost);
    }
}