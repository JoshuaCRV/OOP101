/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package campus.tasks;

/**
 *
 * @author angieluz cervania
 */
import java.util.Scanner;

public class TaskDemo {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter task name: ");
        String inputName = scanner.nextLine();

        System.out.print("Enter estimated minutes: ");
        int inputTime = scanner.nextInt();
        scanner.nextLine(); // consume newline

        System.out.print("Enter priority (LOW, MEDIUM, HIGH): ");
        Priority priority = Priority.valueOf(scanner.nextLine().toUpperCase());

        // Using our exact same generic TaskBox classes
        TaskBox<String> taskNameBox = new TaskBox<>(inputName);
        TaskBox<Integer> taskTimeBox = new TaskBox<>(inputTime); // Autoboxing primitive int

        String actionMessage = switch (priority) {
            case HIGH -> "DO FIRST";
            case MEDIUM -> "SCHEDULE";
            case LOW -> "OPTIONAL";
        };

        System.out.println("\n--- Task Summary ---");
        System.out.println("Task: " + taskNameBox.getItem());
        System.out.println("Estimated Minutes: " + taskTimeBox.getItem());
        System.out.println("Priority: " + priority);
        System.out.println("Action: " + actionMessage);
        
        scanner.close();
    }
}
