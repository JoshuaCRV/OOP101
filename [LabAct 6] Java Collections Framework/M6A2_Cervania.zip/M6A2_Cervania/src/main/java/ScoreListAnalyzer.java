/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author angieluz cervania
 */
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class ScoreListAnalyzer {
    public static void main(String[] args) {
        List<Integer> scores = new ArrayList<>();
        Scanner scanner = new Scanner(System.in);

        scores.add(88);
        scores.add(72);
        scores.add(95);
        scores.add(81);
        scores.add(72);

        System.out.println("Original Score List: " + scores);

        double sum = 0;
        for (int score : scores) {
            sum += score;
        }
        double average = sum / scores.size();
        System.out.println("Average Score: " + average);

        Collections.sort(scores);
        System.out.println("Sorted Score List: " + scores);

        searchScore(scores, 81);
        searchScore(scores, 100);

        scanner.close();
    }

    private static void searchScore(List<Integer> scores, int target) {
        int index = Collections.binarySearch(scores, target);
        if (index >= 0) {
            System.out.println("Score " + target + " found at index " + index + ".");
        } else {
            System.out.println("Score " + target + " Not found.");
        }
    }
}
