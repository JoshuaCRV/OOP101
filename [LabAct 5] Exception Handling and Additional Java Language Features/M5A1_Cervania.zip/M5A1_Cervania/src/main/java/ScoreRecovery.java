/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author angieluz cervania
 */
import java.util.Scanner;
public class ScoreRecovery {

    // Validates the score range and throws custom checked exception if out of bounds
    public static void evaluateScore(String scoreText) throws InvalidScoreException {
        int score = Integer.parseInt(scoreText); // Throws NumberFormatException if invalid format
        
        if (score < 0 || score > 100) {
            throw new InvalidScoreException("Invalid score. Score must be between 0 and 100.");
        }
        
        // Passing mark is 75
        String status = (score >= 75) ? "PASSED" : "FAILED";
        System.out.println(score + " - " + status);
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Loop for 3 entries (or however many you want to prompt for)
        for (int i = 1; i <= 3; i++) {
            System.out.print("Enter score attempt " + i + ": ");
            String entry = scanner.nextLine();
            
            try {
                evaluateScore(entry);
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a numeric score.");
            } catch (InvalidScoreException e) {
                System.out.println(e.getMessage());
            } finally {
                System.out.println("Validation attempt completed");
            }
        }
        scanner.close();
    }
}