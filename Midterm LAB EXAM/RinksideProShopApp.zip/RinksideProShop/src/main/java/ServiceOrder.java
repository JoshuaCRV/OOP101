/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author angieluz cervania
 */
import java.util.ArrayList;
import java.util.List;

public class ServiceOrder implements Billable {
    private String orderId;
    private Customer customer;
    private Technician assignedTechnician;
    private List<SkateService> services;
    private OrderStatus orderStatus;
    private String dropOffDate;
    private String pickUpDate;

    public ServiceOrder(String orderId, Customer customer, String dropOffDate) {
        this.orderId = orderId;
        this.customer = customer;
        this.dropOffDate = dropOffDate;
        this.pickUpDate = "N/A";
        this.services = new ArrayList<>();
        this.orderStatus = OrderStatus.DROPPED_OFF;
        this.assignedTechnician = null;
    }

    public String getOrderId() {
        return orderId;
    }

    public Customer getCustomer() {
        return customer;
    }

    public Technician getAssignedTechnician() {
        return assignedTechnician;
    }

    public OrderStatus getOrderStatus() {
        return orderStatus;
    }

    public List<SkateService> getServices() {
        return services;
    }

    public void addService(SkateService service) {
        if (service != null) {
            this.services.add(service);
        }
    }

    public boolean assignTechnician(Technician tech) {
        if (tech != null && tech.canAcceptOrder()) {
            if (this.assignedTechnician != null) {
                this.assignedTechnician.decrementActiveOrders();
            }
            this.assignedTechnician = tech;
            this.assignedTechnician.incrementActiveOrders();
            if (this.orderStatus == OrderStatus.DROPPED_OFF) {
                this.orderStatus = OrderStatus.ASSIGNED;
            }
            return true;
        }
        return false;
    }

    public boolean updateStatus(OrderStatus newStatus) {
        if (newStatus == OrderStatus.READY_FOR_PICKUP && !isAllServicesCompleted()) {
            return false;
        }
        this.orderStatus = newStatus;
        return true;
    }

    public boolean isAllServicesCompleted() {
        if (services.isEmpty()) {
            return false;
        }
        for (SkateService service : services) {
            if (!service.isCompleted()) {
                return false;
            }
        }
        return true;
    }

    public boolean canBePickedUp() {
        return isAllServicesCompleted() && this.orderStatus == OrderStatus.READY_FOR_PICKUP;
    }

    public boolean markPickedUp(String pickUpDate) {
        if (canBePickedUp()) {
            this.orderStatus = OrderStatus.PICKED_UP;
            this.pickUpDate = pickUpDate;
            if (this.assignedTechnician != null) {
                this.assignedTechnician.decrementActiveOrders();
            }
            return true;
        }
        return false;
    }

    @Override
    public double calculateTotalCost() {
        double total = 0.0;
        for (SkateService service : services) {
            total += service.calculateTotalCost();
        }
        return total;
    }

    @Override
    public String getFormattedSummary() {
        StringBuilder sb = new StringBuilder();
        sb.append("==================================================\n");
        sb.append(String.format("SERVICE ORDER RECEIPT - #%s\n", orderId));
        sb.append("==================================================\n");
        sb.append(String.format("Customer    : %s (%s)\n", customer.getName(), customer.getSkateBrandModel()));
        sb.append(String.format("Phone       : %s\n", customer.getPhoneNumber()));
        sb.append(String.format("Technician  : %s\n", assignedTechnician != null ? assignedTechnician.getName() : "Unassigned"));
        sb.append(String.format("Status      : %s\n", orderStatus));
        sb.append(String.format("Drop-Off    : %s | Pick-Up: %s\n", dropOffDate, pickUpDate));
        sb.append("--------------------------------------------------\n");
        sb.append("Requested Services:\n");
        for (SkateService service : services) {
            sb.append("  * ").append(service.getFormattedSummary()).append("\n");
        }
        sb.append("--------------------------------------------------\n");
        sb.append(String.format("TOTAL DUE   : PHP %.2f\n", calculateTotalCost()));
        sb.append("==================================================");
        return sb.toString();
    }
}