/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author angieluz cervania
 */
public class SharpeningService extends SkateService {
    private String radiusOfHollow;
    private boolean isCustomRadius;

    public SharpeningService(String serviceId, double basePrice, String radiusOfHollow, boolean isCustomRadius) {
        super(serviceId, "Skate Sharpening", basePrice);
        if (radiusOfHollow == null || radiusOfHollow.trim().isEmpty() || radiusOfHollow.trim().startsWith("-")) {
            this.radiusOfHollow = "1/2 inch";
        } else {
            this.radiusOfHollow = radiusOfHollow.trim();
        }
        this.isCustomRadius = isCustomRadius;
    }

    public String getRadiusOfHollow() {
        return this.radiusOfHollow;
    }

    public boolean isCustomRadius() {
        return this.isCustomRadius;
    }

    @Override
    public double calculateServiceFee() {
        double customRadiusSurcharge = isCustomRadius ? 150.0 : 0.0;
        return getBasePrice() + customRadiusSurcharge;
    }

    @Override
    public String getFormattedSummary() {
        return super.getFormattedSummary() + String.format(" | ROH: %s | Custom Radius: %s",
                radiusOfHollow,
                isCustomRadius ? "Yes (+PHP 150.00)" : "No");
    }
}
