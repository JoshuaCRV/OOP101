/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author angieluz cervania
 */
public class Technician {
    private String technicianId;
    private String name;
    private String specialty;
    private int activeOrdersCount;
    private static final int MAX_WORKLOAD = 3;

    public Technician(String technicianId, String name, String specialty) {
        this.technicianId = technicianId;
        this.name = name;
        this.specialty = specialty;
        this.activeOrdersCount = 0;
    }

    public String getTechnicianId() {
        return technicianId;
    }

    public String getName() {
        return name;
    }

    public String getSpecialty() {
        return specialty;
    }

    public int getActiveOrdersCount() {
        return activeOrdersCount;
    }

    public boolean canAcceptOrder() {
        return activeOrdersCount < MAX_WORKLOAD;
    }

    public void incrementActiveOrders() {
        this.activeOrdersCount++;
    }

    public void decrementActiveOrders() {
        if (this.activeOrdersCount > 0) {
            this.activeOrdersCount--;
        }
    }
}