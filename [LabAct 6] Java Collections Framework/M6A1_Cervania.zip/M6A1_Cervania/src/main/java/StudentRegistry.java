/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author angieluz cervania
 */
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class StudentRegistry {
    public static void main(String[] args) {

        Map<String, String> students = new HashMap<>();
        Scanner scanner = new Scanner(System.in);

        // Pre-load initial required entries
        students.put("2026-001", "Ana Cruz");
        students.put("2026-002", "Ben Lim");
        students.put("2026-003", "Cara Reyes");

        System.out.println("=== Student Registry Initialized ===");


        System.out.print("\nEnter a student ID to add (test duplicate): ");
        String inputId = scanner.nextLine();

        if (students.containsKey(inputId)) {
            System.out.println("Rejected duplicate ID: " + inputId + ". Existing record remains stored.");
        } else {
            System.out.print("Enter student name for " + inputId + ": ");
            String inputName = scanner.nextLine();
            students.put(inputId, inputName);
            System.out.println("Successfully added " + inputName + ".");
        }


        System.out.print("\nEnter a student ID to search: ");
        String searchId = scanner.nextLine();

        if (students.containsKey(searchId)) {
            System.out.println("ID " + searchId + " found: " + students.get(searchId));
        } else {
            System.out.println("ID " + searchId + ": Student not found.");
        }


        System.out.println("\n--- All Accepted Student Records ---");
        for (Map.Entry<String, String> entry : students.entrySet()) {
            System.out.println("ID: " + entry.getKey() + " | Name: " + entry.getValue());
        }

        scanner.close();
    }
}