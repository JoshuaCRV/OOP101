/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author angieluz cervania
 */
public class BladeMountingService extends SkateService {
    private String mountType;
    private int screwCount;

    public BladeMountingService(String serviceId, double basePrice, String mountType, int screwCount) {
        super(serviceId, "Blade Mounting", basePrice);
        this.mountType = mountType;
        this.screwCount = screwCount;
    }

    public String getMountType() {
        return this.mountType;
    }

    public int getScrewCount() {
        return this.screwCount;
    }

    @Override
    public double calculateServiceFee() {
        double fullMountSurcharge = "FULL".equalsIgnoreCase(mountType) ? 200.0 : 0.0;
        return getBasePrice() + fullMountSurcharge;
    }

    @Override
    public String getFormattedSummary() {
        return super.getFormattedSummary() + String.format(" | Mount Type: %s | Screws: %d",
                mountType,
                screwCount);
    }
}
