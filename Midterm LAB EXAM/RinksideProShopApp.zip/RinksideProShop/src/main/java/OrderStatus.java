/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author angieluz cervania
 */
public enum OrderStatus {
    DROPPED_OFF,
    ASSIGNED,
    IN_PROGRESS,
    READY_FOR_PICKUP,
    PICKED_UP
}
