/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package campus.tasks;

/**
 *
 * @author angieluz cervania
 */
public class TaskBox<T> {
    private T item;

    public TaskBox(T item) {
        this.item = item;
    }

    public T getItem() {
        return item;
    }
}