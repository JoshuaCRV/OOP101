/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author angieluz cervania
 */
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class RinksideProShopApp {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Pre-seeded shop technicians for assignment testing
        List<Technician> techList = new ArrayList<>();
        techList.add(new Technician("TECH-01", "Coach Lucas", "Blade Alignment & Sharpening"));
        techList.add(new Technician("TECH-02", "Elena Rostova", "Boot Heat Molding & Fitting"));

        ServiceOrder currentOrder = null;
        int serviceIdCounter = 1;
        int orderIdCounter = 1001;

        boolean running = true;

        System.out.println("==================================================");
        System.out.println("   RINKSIDE ICE SKATE PRO-SHOP MANAGEMENT SYSTEM  ");
        System.out.println("==================================================");

        do {
            System.out.println("\nMAIN MENU");
            System.out.println("[1] Create New Service Order");
            System.out.println("[2] Add Service to Current Order");
            System.out.println("[3] Assign Technician to Order");
            System.out.println("[4] Mark Service Work as Completed");
            System.out.println("[5] Update Order Status / Process Pick-Up");
            System.out.println("[6] View Current Order Receipt Summary");
            System.out.println("[7] Exit System");
            System.out.print("Enter choice (1-7): ");

            String choiceInput = scanner.nextLine().trim();

            if ("1".equals(choiceInput)) {
                System.out.println("\n--- CREATE NEW SERVICE ORDER ---");
                System.out.print("Enter Customer Name: ");
                String name = scanner.nextLine().trim();

                System.out.print("Enter Phone Number: ");
                String phone = scanner.nextLine().trim();

                System.out.print("Enter Skate Brand & Model (e.g., Jackson Freestyle): ");
                String skate = scanner.nextLine().trim();

                System.out.print("Enter Drop-Off Date (YYYY-MM-DD): ");
                String dropDate = scanner.nextLine().trim();

                Customer customer = new Customer("CST-" + (100 + orderIdCounter % 100), name, phone, skate);
                currentOrder = new ServiceOrder("ORD-" + orderIdCounter++, customer, dropDate);

                System.out.println("-> Success: Service Order #" + currentOrder.getOrderId() + " created for " + customer.getName() + "!");

            } else if ("2".equals(choiceInput)) {
                if (currentOrder == null) {
                    System.out.println("-> Error: Please create a Service Order first (Option 1).");
                } else {
                    System.out.println("\n--- ADD SERVICE TO ORDER #" + currentOrder.getOrderId() + " ---");
                    System.out.println("Select Service Type:");
                    System.out.println("1. Skate Sharpening");
                    System.out.println("2. Blade Mounting");
                    System.out.println("3. Boot Heat Molding");
                    System.out.println("4. Skate Repair");
                    System.out.print("Enter type (1-4): ");

                    String serviceChoice = scanner.nextLine().trim();
                    String sId = "SRV-" + String.format("%02d", serviceIdCounter++);

                    if ("1".equals(serviceChoice)) {
                        System.out.print("Enter Base Price (PHP): ");
                        double price = Double.parseDouble(scanner.nextLine().trim());
                        if (price < 0.0) {
                            System.out.println("-> Error: Base price cannot be negative! Operation canceled.");
                        } else {
                            System.out.print("Enter Radius of Hollow (e.g., 1/2 inch): ");
                            String roh = scanner.nextLine().trim();
                            if (roh.isEmpty() || roh.startsWith("-")) {
                                System.out.println("-> Error: Radius of Hollow cannot be empty or negative! Operation canceled.");
                            } else {
                                System.out.print("Is this a Custom Radius? (yes/no): ");
                                boolean isCustom = scanner.nextLine().trim().equalsIgnoreCase("yes");

                                SkateService sharpening = new SharpeningService(sId, price, roh, isCustom);
                                currentOrder.addService(sharpening);
                                System.out.println("-> Added Skate Sharpening service!");
                            }
                        }

                    } else if ("2".equals(serviceChoice)) {
                        System.out.print("Enter Base Price (PHP): ");
                        double price = Double.parseDouble(scanner.nextLine().trim());
                        if (price < 0.0) {
                            System.out.println("-> Error: Base price cannot be negative! Operation canceled.");
                        } else {
                            System.out.print("Enter Mount Type (TEMPORARY/FULL): ");
                            String mountType = scanner.nextLine().trim().toUpperCase();
                            System.out.print("Enter Screw Count: ");
                            int screws = Integer.parseInt(scanner.nextLine().trim());
                            if (screws < 0) {
                                System.out.println("-> Error: Screw count cannot be negative! Operation canceled.");
                            } else {
                                SkateService mounting = new BladeMountingService(sId, price, mountType, screws);
                                currentOrder.addService(mounting);
                                System.out.println("-> Added Blade Mounting service!");
                            }
                        }

                    } else if ("3".equals(serviceChoice)) {
                        System.out.print("Enter Base Price (PHP): ");
                        double price = Double.parseDouble(scanner.nextLine().trim());
                        if (price < 0.0) {
                            System.out.println("-> Error: Base price cannot be negative! Operation canceled.");
                        } else {
                            System.out.print("Enter Heating Duration (Minutes): ");
                            int mins = Integer.parseInt(scanner.nextLine().trim());
                            if (mins < 0) {
                                System.out.println("-> Error: Heating duration cannot be negative! Operation canceled.");
                            } else {
                                System.out.print("Requires Custom Spot Punching? (yes/no): ");
                                boolean customPunch = scanner.nextLine().trim().equalsIgnoreCase("yes");

                                SkateService molding = new HeatMoldingService(sId, price, mins, customPunch);
                                currentOrder.addService(molding);
                                System.out.println("-> Added Boot Heat Molding service!");
                            }
                        }

                    } else if ("4".equals(serviceChoice)) {
                        System.out.print("Enter Base Price (PHP): ");
                        double price = Double.parseDouble(scanner.nextLine().trim());
                        if (price < 0.0) {
                            System.out.println("-> Error: Base price cannot be negative! Operation canceled.");
                        } else {
                            System.out.print("Enter Repair Description: ");
                            String desc = scanner.nextLine().trim();
                            System.out.print("Enter Replacement Parts Cost (PHP): ");
                            double parts = Double.parseDouble(scanner.nextLine().trim());
                            if (parts < 0.0) {
                                System.out.println("-> Error: Parts cost cannot be negative! Operation canceled.");
                            } else {
                                SkateService repair = new RepairService(sId, price, desc, parts);
                                currentOrder.addService(repair);
                                System.out.println("-> Added Skate Repair service!");
                            }
                        }

                    } else {
                        System.out.println("-> Invalid service choice!");
                    }
                }

            } else if ("3".equals(choiceInput)) {
                if (currentOrder == null) {
                    System.out.println("-> Error: No active Service Order found.");
                } else {
                    System.out.println("\n--- ASSIGN TECHNICIAN ---");
                    System.out.println("Available Technicians:");
                    for (int i = 0; i < techList.size(); i++) {
                        Technician t = techList.get(i);
                        System.out.println("[" + (i + 1) + "] " + t.getName() + " (" + t.getSpecialty() + ") | Active Orders: " + t.getActiveOrdersCount() + "/3");
                    }
                    System.out.print("Select Technician (1-" + techList.size() + "): ");
                    int techIndex = Integer.parseInt(scanner.nextLine().trim()) - 1;

                    if (techIndex >= 0 && techIndex < techList.size()) {
                        Technician selectedTech = techList.get(techIndex);
                        boolean assigned = currentOrder.assignTechnician(selectedTech);
                        if (assigned) {
                            System.out.println("-> Successfully assigned " + selectedTech.getName() + " to Order #" + currentOrder.getOrderId());
                        } else {
                            System.out.println("-> Assignment failed: Technician workload is full!");
                        }
                    } else {
                        System.out.println("-> Invalid technician selection.");
                    }
                }

            } else if ("4".equals(choiceInput)) {
                if (currentOrder == null || currentOrder.getServices().isEmpty()) {
                    System.out.println("-> Error: Order has no services to complete.");
                } else {
                    System.out.println("\n--- MARK SERVICE WORK AS COMPLETED ---");
                    List<SkateService> services = currentOrder.getServices();
                    for (int i = 0; i < services.size(); i++) {
                        SkateService s = services.get(i);
                        System.out.println("[" + (i + 1) + "] " + s.getServiceName() + " | Status: " + (s.isCompleted() ? "COMPLETED" : "PENDING"));
                    }
                    System.out.print("Select service to mark complete (1-" + services.size() + "): ");
                    int sIndex = Integer.parseInt(scanner.nextLine().trim()) - 1;

                    if (sIndex >= 0 && sIndex < services.size()) {
                        services.get(sIndex).markCompleted();
                        System.out.println("-> Service marked as COMPLETED!");
                    } else {
                        System.out.println("-> Invalid selection.");
                    }
                }

            } else if ("5".equals(choiceInput)) {
                if (currentOrder == null) {
                    System.out.println("-> Error: No active order to update.");
                } else {
                    System.out.println("\n--- UPDATE ORDER STATUS / PROCESS PICKUP ---");
                    System.out.println("Current Status: " + currentOrder.getOrderStatus());
                    System.out.println("1. Set to IN_PROGRESS");
                    System.out.println("2. Set to READY_FOR_PICKUP");
                    System.out.println("3. Process Customer PICK_UP");
                    System.out.print("Select action (1-3): ");
                    String statusChoice = scanner.nextLine().trim();

                    if ("1".equals(statusChoice)) {
                        currentOrder.updateStatus(OrderStatus.IN_PROGRESS);
                        System.out.println("-> Order status updated to IN_PROGRESS.");
                    } else if ("2".equals(statusChoice)) {
                        boolean updated = currentOrder.updateStatus(OrderStatus.READY_FOR_PICKUP);
                        if (updated) {
                            System.out.println("-> Order status updated to READY_FOR_PICKUP.");
                        } else {
                            System.out.println("-> Cannot set READY_FOR_PICKUP: Unfinished sub-services remain!");
                        }
                    } else if ("3".equals(statusChoice)) {
                        System.out.print("Enter Pick-Up Date (YYYY-MM-DD): ");
                        String pDate = scanner.nextLine().trim();
                        boolean pickedUp = currentOrder.markPickedUp(pDate);
                        if (pickedUp) {
                            System.out.println("-> Pick-up successfully processed! Order complete.");
                        } else {
                            System.out.println("-> Pick-up failed! Ensure status is READY_FOR_PICKUP and all work is done.");
                        }
                    } else {
                        System.out.println("-> Invalid choice.");
                    }
                }

            } else if ("6".equals(choiceInput)) {
                if (currentOrder == null) {
                    System.out.println("-> Error: No order available to display.");
                } else {
                    System.out.println("\n" + currentOrder.getFormattedSummary());
                }

            } else if ("7".equals(choiceInput)) {
                running = false;
                System.out.println("\nExiting Rinkside Pro-Shop System. Goodbye!");

            } else {
                System.out.println("-> Choice out of range! Please enter an option from 1 to 7.");
            }

        } while (running);

        scanner.close();
    }
}